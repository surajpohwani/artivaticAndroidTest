package com.surajpohwani.backgroungcounterapp

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper



class BackgroundService : Service() {
    companion object{
        const val UPDATE_ACTION = "UpdateTheCounter"
        const val COUNTER_VALUE = "counterValue"
    }
    override fun onBind(intent: Intent?): IBinder? {
        var counter = 0
        val handler = Handler(Looper.getMainLooper())

        handler.postDelayed(Runnable {
            counter++
            val intent = Intent(UPDATE_ACTION)
            intent.putExtra(COUNTER_VALUE, counter)
            sendBroadcast(intent)
        }, 1000)

        return null
    }
}
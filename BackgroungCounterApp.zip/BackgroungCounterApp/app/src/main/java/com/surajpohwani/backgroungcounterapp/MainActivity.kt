package com.surajpohwani.backgroungcounterapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var tv_counter: TextView
    lateinit var broadcastReceiver: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv_counter = findViewById(R.id.tv_counter)
        startService(Intent(this, BackgroundService::class.java))

    }

    override fun onResume() {
        super.onResume()
        broadcastReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                intent?.let {
                    if (intent.action == BackgroundService.UPDATE_ACTION) {
                        val counterValue = it.getIntExtra(BackgroundService.COUNTER_VALUE, 0)
                        tv_counter.text = counterValue.toString()
                        if (counterValue % 2 == 0)
                            tv_counter.setTextColor(Color.parseColor("#FF0000"))
                        else
                            tv_counter.setTextColor(Color.parseColor("#00FF00"))
                    }
                }
            }

        }

        registerReceiver(broadcastReceiver, IntentFilter(BackgroundService.UPDATE_ACTION))
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadcastReceiver)
        stopService(Intent(this, BackgroundService::class.java))
    }
}